# Title: MHS-Mamba: A Multi-Hierarchical Semantic Model for UAV Hyperspectral Image Classification
# Author: Fengnian Zhao
# Completion Date: 2025.5
# Article Link: https://ieeexplore.ieee.org/document/11152542
# Code Link: https://github.com/KustAIRS/JSTARS-MHS-Mamba
# Please refer to the README.txt file for the detailed usage.
# Note: This code is for research purpose only. The code is not for commercial use.
from einops import rearrange
import numpy as np
import matplotlib.pyplot as plt
from operator import truediv
import scipy.io as sio
import torch
import torch.utils.data as Data
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
import os


def _th_mean_std_normalize(image, mean=(123.675, 116.28, 103.53), std=(58.395, 57.12, 57.375)):
    """ this version faster than torchvision.transforms.functional.normalize

    Args:
        image: 3-D or 4-D array of shape [batch (optional) , height, width, channel]
        mean:  a list or tuple or ndarray
        std: a list or tuple or ndarray

    Returns:

    """
    shape = [1] * image.dim()
    shape[-1] = -1
    mean = torch.tensor(mean, requires_grad=False).reshape(*shape)
    std = torch.tensor(std, requires_grad=False).reshape(*shape)

    return image.sub(mean).div(std)


def _np_mean_std_normalize(image, mean=(123.675, 116.28, 103.53), std=(58.395, 57.12, 57.375)):
    """

    Args:
        image: 3-D array of shape [height, width, channel]
        mean:  a list or tuple or ndarray
        std: a list or tuple or ndarray

    Returns:

    """
    if not isinstance(mean, np.ndarray):
        mean = np.array(mean, np.float32)
    if not isinstance(std, np.ndarray):
        std = np.array(std, np.float32)
    shape = [1] * image.ndim
    shape[-1] = -1
    return (image - mean.reshape(shape)) / std.reshape(shape)


def mean_std_normalize(image, mean=(123.675, 116.28, 103.53), std=(58.395, 57.12, 57.375)):
    """

    Args:
        image: 3-D array of shape [height, width, channel]
        mean:  a list or tuple
        std: a list or tuple

    Returns:

    """
    if isinstance(image, np.ndarray):
        return _np_mean_std_normalize(image, mean, std)
    elif isinstance(image, torch.Tensor):
        return _th_mean_std_normalize(image, mean, std)
    else:
        raise ValueError('The type {} is not support'.format(type(image)))


# 对高光谱数据 X 应用 PCA 变换
def applyPCA(X, numComponents):
    newX = np.reshape(X, (-1, X.shape[2]))
    pca = PCA(n_components=numComponents, whiten=True)
    newX = pca.fit_transform(newX)
    newX = np.reshape(newX, (X.shape[0], X.shape[1], numComponents))

    return newX


def divisible_pad(image_list, size_divisor=128, to_tensor=True):
    """

    Args:
        image_list: a list of images with shape [channel, height, width]
        size_divisor: int
        to_tensor: whether to convert to tensor
    Returns:
        blob: 4-D ndarray of shape [batch, channel, divisible_max_height, divisible_max_height]
    """
    max_shape = np.array([im.shape for im in image_list]).max(axis=0)

    max_shape[1] = int(np.ceil(max_shape[1] / size_divisor) * size_divisor)
    max_shape[2] = int(np.ceil(max_shape[2] / size_divisor) * size_divisor)

    if to_tensor:
        storage = torch.FloatStorage._new_shared(len(image_list) * np.prod(max_shape))
        out = torch.Tensor(storage).view([len(image_list), max_shape[0], max_shape[1], max_shape[2]])
        out = out.zero_()
    else:
        out = np.zeros([len(image_list), max_shape[0], max_shape[1], max_shape[2]], np.float32)

    for i, resized_im in enumerate(image_list):
        out[i, :, 0:resized_im.shape[1], 0:resized_im.shape[2]] = torch.from_numpy(resized_im)

    return out


def load_dataset(PC=30, rate=None, applypca=False, flag=None, disjoin=False, crop=False):
    if disjoin:
        if flag == "1":
            image_dir = './data/disjoin/Indian_pines.mat'
            train_dir = './data/disjoin/IP_training.mat'
            test_dir = './data/disjoin/IP_testing.mat'
        if flag == "2":
            image_dir = './data/disjoin/PaviaU.mat'
            train_dir = './data/disjoin/PU_training.mat'
            test_dir = './data/disjoin/PU_testing.mat'
        if flag == "3":
            image_dir = './data/disjoin/UH2013w.mat'
            train_dir = './data/disjoin/UH2013_TR.mat'
            test_dir = './data/disjoin/UH2013_TE.mat'

        im_type = ".mat"
        my_array = np.array([1, 1])

        data_dict1 = sio.loadmat(image_dir)  # need an r!
        for key in data_dict1.keys():
            if type(data_dict1[key]) == type(my_array):
                data_hsi = data_dict1[key]
                if image_dir.split("\\")[-1] == "xiongan.mat":
                    data_hsi = rearrange(data_hsi, 'c h w -> h w c')
        data_dict2 = sio.loadmat(train_dir)
        for key in data_dict2.keys():
            if type(data_dict2[key]) == type(my_array):
                TR_gt = data_dict2[key].astype(float)
        data_dict3 = sio.loadmat(test_dir)
        for key in data_dict3.keys():
            if type(data_dict3[key]) == type(my_array):
                TE_gt = data_dict3[key].astype(float)

    else:
        my_array = np.array([1, 1])
        if flag == "4":
            image_dir = './data/HanChuan/WHU_Hi_HanChuan.mat'
            train_dir = './data/HanChuan/WHU_Hi_HanChuan_gt.mat'
            rate = 0.01
            im_type = ".mat"

            data_dict1 = sio.loadmat(image_dir)
            data_hsi = data_dict1['WHU_Hi_HanChuan']
            data_dict2 = sio.loadmat(train_dir)
            lab = data_dict2['WHU_Hi_HanChuan_gt']
            num_class = int(np.max(lab))
        elif flag == "5":
            image_dir = '/media/rslab/Workplace/Huanglh/datasets/QUH-Tangdaowan.mat'
            train_dir = '/media/rslab/Workplace/Huanglh/datasets/QUH-Tangdaowan_GT.mat'
            rate = 0.01
            im_type = ".mat"

            data_dict1 = sio.loadmat(image_dir)
            data_hsi = data_dict1['Tangdaowan']
            data_dict2 = sio.loadmat(train_dir)
            lab = data_dict2['TangdaowanGT']
            num_class = int(np.max(lab))
        elif flag == "6":
            image_dir = './data/QUH/QUH-Pingan.mat'
            train_dir = './data/QUH/QUH-Pingan_GT.mat'
            rate = 0.01
            im_type = ".mat"

            data_dict1 = sio.loadmat(image_dir)
            data_hsi = data_dict1['Haigang']
            data_dict2 = sio.loadmat(train_dir)
            lab = data_dict2['HaigangGT']
            num_class = int(np.max(lab))
        elif flag == "7":
            image_dir = './data/QUH/QingYuncrop.mat'
            train_dir = './data/QUH/QingYuncropgt.mat'
            rate = 0.01
            im_type = ".mat"

            data_dict1 = sio.loadmat(image_dir)
            data_hsi = data_dict1['qingyuncaijian']
            data_dict2 = sio.loadmat(train_dir)
            lab = data_dict2['dqygtcr']
            num_class = int(np.max(lab))
        elif flag == "8":
            image_dir = './data/HongHu/WHU_Hi_HongHu.mat'
            train_dir = './data/HongHu/WHU_Hi_HongHu_gt.mat'
            rate = 0.01
            im_type = ".mat"

            data_dict1 = sio.loadmat(image_dir)
            data_hsi = data_dict1['WHU_Hi_HongHu']
            data_dict2 = sio.loadmat(train_dir)
            lab = data_dict2['WHU_Hi_HongHu_gt']
            num_class = int(np.max(lab))
        elif flag == "9":
            image_dir = '/media/rslab/Workplace/Huanglh/datasets/GF5295.mat'
            train_dir = '/media/rslab/Workplace/Huanglh/datasets/GF5295_gt.mat'
            rate = 0.01
            im_type = ".mat"

            data_dict1 = sio.loadmat(image_dir)
            data_hsi = data_dict1['Data']
            data_dict2 = sio.loadmat(train_dir)
            lab = data_dict2['x___']
            num_class = int(np.max(lab))
        elif flag == "10":
            image_dir = '/media/rslab/Workplace/Huanglh/datasets/QUH-Tangdaowan.mat'
            train_dir = '/media/rslab/Workplace/Huanglh/datasets/QUH-Tangdaowan_GT.mat'
            rate = 600
            im_type = ".mat"

            data_dict1 = sio.loadmat(image_dir)
            data_hsi = data_dict1['Tangdaowan']
            data_dict2 = sio.loadmat(train_dir)
            lab = data_dict2['TangdaowanGT']
            num_class = int(np.max(lab))

        TR_gt = np.zeros([lab.shape[0], lab.shape[1]], dtype=float)
        TE_gt = np.zeros([lab.shape[0], lab.shape[1]], dtype=float)

        # Tangdaowan数据集的特殊处理
        if flag == "5":
            print("Tangdaowan Dataset Class Distribution:")
            print("----------------------------------------")
            for i in range(num_class):
                idx, idy = np.where(lab == i + 1)
                total_samples = len(idx)

                if total_samples == 0:  # 处理空类别
                    print(f"Class {i + 1}: Total=0, Train=0, Test=0")
                    continue

                ID = np.random.permutation(total_samples)
                idx = idx[ID]
                idy = idy[ID]

                # 标签3和4取200个样本，其余取600个样本
                if i + 1 in [12, 14]:  # 标签3和4 (索引2和3)
                    train_samples = min(200, total_samples)
                else:
                    train_samples = min(600, total_samples)

                if total_samples <= 15:
                    tr_x = idx[:min(15, total_samples)]
                    tr_y = idy[:min(15, total_samples)]
                    te_x = idx[min(15, total_samples):]
                    te_y = idy[min(15, total_samples):]
                else:
                    tr_x = idx[:train_samples]
                    tr_y = idy[:train_samples]
                    te_x = idx[train_samples:]
                    te_y = idy[train_samples:]

                for j in range(len(tr_x)):
                    TR_gt[tr_x[j], tr_y[j]] = lab[tr_x[j], tr_y[j]]
                for j in range(len(te_x)):
                    TE_gt[te_x[j], te_y[j]] = lab[te_x[j], te_y[j]]

                # 打印每个类别的训练和测试样本数量
                train_count = len(tr_x)
                test_count = len(te_x)
                print(f"Class {i + 1}: Total={total_samples}, Train={train_count}, Test={test_count}")
            print("----------------------------------------")
        else:  # 其他数据集保持原有逻辑
            for i in range(num_class):
                idx, idy = np.where(lab == i + 1)
                ID = np.random.permutation(len(idx))
                idx = idx[ID]
                idy = idy[ID]
                if rate > 1:
                    if rate > len(idx):
                        tr_x = idx[0:15]
                        tr_y = idy[0:15]
                        te_x = idx[15:]
                        te_y = idy[15:]
                    else:
                        tr_x = idx[0:rate]
                        tr_y = idy[0:rate]
                        te_x = idx[rate:]
                        te_y = idy[rate:]
                else:
                    tr_x = idx[0:int(len(idx) * rate) + 1]
                    tr_y = idy[0:int(len(idx) * rate) + 1]
                    te_x = idx[int(len(idx) * rate) + 1:]
                    te_y = idy[int(len(idx) * rate) + 1:]
                for j in range(len(tr_x)):
                    TR_gt[tr_x[j], tr_y[j]] = lab[tr_x[j], tr_y[j]]
                for j in range(len(te_x)):
                    TE_gt[te_x[j], te_y[j]] = lab[te_x[j], te_y[j]]

    # 数据裁剪部分
    if crop:
        h, w, _ = data_hsi.shape
        h_start = int((h - h * 0.7) / 2)
        h_end = h_start + int(h * 0.7)
        w_start = int((w - w * 0.7) / 2)
        w_end = w_start + int(w * 0.7)
        data_hsi = data_hsi[h_start:h_end, w_start:w_end, :]
        TR_gt = TR_gt[h_start:h_end, w_start:w_end]
        TE_gt = TE_gt[h_start:h_end, w_start:w_end]

    # mean - std
    # im_cmean = data_hsi.reshape((-1, data_hsi.shape[-1])).mean(axis=0)
    # im_cstd = data_hsi.reshape((-1, data_hsi.shape[-1])).std(axis=0)
    # data_hsi = mean_std_normalize(data_hsi, im_cmean, im_cstd)

    # 区间缩放，返回值为缩放到[0, 1]区间的数据
    image_x, image_y, BAND = data_hsi.shape
    data_hsi = data_hsi.reshape((image_x * image_y, BAND))
    data_hsi = MinMaxScaler().fit_transform(data_hsi)
    data_hsi = data_hsi.reshape((image_x, image_y, BAND))
    if applypca:
        data_hsi = applyPCA(data_hsi, numComponents=PC)

    TOTAL_SIZE = TR_gt.shape[0] * TR_gt.shape[1]
    TRAIN_SIZE = TR_gt[TR_gt > 0].size
    TEST_SIZE = TE_gt[TE_gt > 0].size
    GT = TR_gt + TE_gt
    VALIDATION_SPLIT = 0
    return data_hsi, GT, TOTAL_SIZE, TRAIN_SIZE, TEST_SIZE, VALIDATION_SPLIT, TR_gt, TE_gt


def save_cmap(img, cmap, fname):
    sizes = np.shape(img)
    height = float(sizes[0])
    width = float(sizes[1])

    fig = plt.figure()
    fig.set_size_inches(width / height, 1, forward=False)
    ax = plt.Axes(fig, [0., 0., 1., 1.])
    ax.set_axis_off()
    fig.add_axes(ax)

    ax.imshow(img, cmap=cmap)
    plt.savefig(fname, dpi=height)
    plt.close()


def sampling(proportion, ground_truth, TE_gt, TR_gt, map_all=True):
    train = {}
    test = {}
    val = {}
    labels_loc = {}
    if proportion != 1:
        m = np.max(TE_gt)
        for i in range(int(m)):
            TR_indexes = [j for j, x in enumerate(TR_gt.ravel().tolist()) if x == i + 1]
            TE_indexes = [j for j, x in enumerate(TE_gt.ravel().tolist()) if x == i + 1]
            np.random.shuffle(TR_indexes)
            np.random.shuffle(TE_indexes)
            train[i] = TR_indexes[:]
            test[i] = TE_indexes[:]
            val[i] = TE_indexes[:]  # * 0.1
        train_indexes = []
        test_indexes = []
        val_indexes = []
        for i in range(int(m)):
            train_indexes += train[i]
            test_indexes += test[i]
            val_indexes += val[i]

    else:
        if map_all:
            m = np.max(TE_gt)
            for i in range(int(m + 1)):
                TE_indexes = [j for j, x in enumerate(TE_gt.ravel().tolist()) if x == i]
                np.random.shuffle(TE_indexes)
                train[i] = TE_indexes[:1]
                test[i] = TE_indexes[:]
                val[i] = TE_indexes[:]  # -int(len(TE_indexes))* 0.1
            train_indexes = []
            test_indexes = []
            val_indexes = []
            for i in range(int(m + 1)):
                train_indexes += train[i]
                test_indexes += test[i]
                val_indexes += val[i]
        else:
            m = np.max(TE_gt)
            for i in range(int(m)):
                TE_indexes = [j for j, x in enumerate(TE_gt.ravel().tolist()) if x == i + 1]
                np.random.shuffle(TE_indexes)
                train[i] = TE_indexes[:1]
                test[i] = TE_indexes[:]
                val[i] = TE_indexes[:]  # -int(len(TE_indexes)) * 0.1
            train_indexes = []
            test_indexes = []
            val_indexes = []
            for i in range(int(m)):
                train_indexes += train[i]
                test_indexes += test[i]
                val_indexes += val[i]

    np.random.shuffle(train_indexes)
    np.random.shuffle(test_indexes)
    np.random.shuffle(val_indexes)

    trgt_mask_flatten = TR_gt.ravel()
    tegt_mask_flatten = TE_gt.ravel()
    train_indicator = np.zeros_like(trgt_mask_flatten)
    test_indicator = np.zeros_like(tegt_mask_flatten)
    val_indicator = np.zeros_like(tegt_mask_flatten)
    train_indicator[train_indexes] = 1
    test_indicator[test_indexes] = 1
    val_indicator[val_indexes] = 1

    train_indicator = train_indicator.reshape(ground_truth.shape)
    test_indicator = test_indicator.reshape(ground_truth.shape)
    val_indicator = val_indicator.reshape(ground_truth.shape)
    return train_indicator, test_indicator, val_indicator


def aa_and_each_accuracy(confusion_matrix):
    list_diag = np.diag(confusion_matrix)
    list_raw_sum = np.sum(confusion_matrix, axis=1)
    each_acc = np.nan_to_num(truediv(list_diag, list_raw_sum))
    average_acc = np.mean(each_acc)
    return each_acc, average_acc


def classification_map(map, ground_truth, dpi, save_path):
    fig = plt.figure(frameon=False)
    fig.set_size_inches(ground_truth.shape[1] * 2.0 / dpi, ground_truth.shape[0] * 2.0 / dpi)

    ax = plt.Axes(fig, [0., 0., 1., 1.])
    ax.set_axis_off()
    ax.xaxis.set_visible(False)
    ax.yaxis.set_visible(False)
    fig.add_axes(ax)

    ax.imshow(map)
    fig.savefig(save_path, dpi=dpi)

    return 0


def list_to_colormap(x_list):
    y = np.zeros((x_list.shape[0], 3))
    for index, item in enumerate(x_list):
        if item == 0:
            y[index] = np.array([255, 0, 0]) / 255.
        if item == 1:
            y[index] = np.array([0, 255, 0]) / 255.
        if item == 2:
            y[index] = np.array([0, 0, 255]) / 255.
        if item == 3:
            y[index] = np.array([255, 255, 0]) / 255.
        if item == 4:
            y[index] = np.array([0, 255, 255]) / 255.
        if item == 5:
            y[index] = np.array([255, 0, 255]) / 255.
        if item == 6:
            y[index] = np.array([192, 192, 192]) / 255.
        if item == 7:
            y[index] = np.array([128, 128, 128]) / 255.
        if item == 8:
            y[index] = np.array([128, 0, 0]) / 255.
        if item == 9:
            y[index] = np.array([128, 128, 0]) / 255.
        if item == 10:
            y[index] = np.array([0, 128, 0]) / 255.
        if item == 11:
            y[index] = np.array([128, 0, 128]) / 255.
        if item == 12:
            y[index] = np.array([0, 128, 128]) / 255.
        if item == 13:
            y[index] = np.array([0, 0, 128]) / 255.
        if item == 14:
            y[index] = np.array([255, 165, 0]) / 255.
        if item == 15:
            y[index] = np.array([255, 215, 0]) / 255.
        if item == 16:
            y[index] = np.array([105, 45, 194]) / 255.
        if item == 17:
            y[index] = np.array([215, 255, 0]) / 255.
        if item == 18:
            y[index] = np.array([0, 255, 215]) / 255.
        if item == 19:
            y[index] = np.array([192, 0, 0]) / 255.
        if item == 20:
            y[index] = np.array([192, 192, 0]) / 255.
        if item == 21:
            y[index] = np.array([192, 0, 192]) / 255.
        if item == -1:
            y[index] = np.array([0, 0, 0]) / 255.
    return y


def generate_iter(train_indices, test_indices, val_indices, total_indices,
                  whole_data, gt, TR_gt, TE_gt, flag):
    gt_all = gt - 1
    y_train = TR_gt - 1
    y_test = TE_gt - 1

    x_train = whole_data
    x_test_all = whole_data

    x_val = x_test_all
    y_val = y_test

    x_test = x_test_all
    y_test = y_test

    x1_tensor_train = torch.from_numpy(x_train).type(torch.FloatTensor).unsqueeze(0)
    y1_tensor_train = torch.from_numpy(y_train).type(torch.FloatTensor).unsqueeze(0)
    y1_tensor_train_indices = torch.from_numpy(train_indices).type(torch.FloatTensor).unsqueeze(0)
    torch_dataset_train = Data.TensorDataset(x1_tensor_train, y1_tensor_train, y1_tensor_train_indices)

    x1_tensor_valida = torch.from_numpy(x_val).type(torch.FloatTensor).unsqueeze(0)
    y1_tensor_valida = torch.from_numpy(y_val).type(torch.FloatTensor).unsqueeze(0)
    y1_tensor_val_indices = torch.from_numpy(val_indices).type(torch.FloatTensor).unsqueeze(0)
    torch_dataset_valida = Data.TensorDataset(x1_tensor_valida, y1_tensor_valida, y1_tensor_val_indices)

    x1_tensor_test = torch.from_numpy(x_test).type(torch.FloatTensor).unsqueeze(0)
    y1_tensor_test = torch.from_numpy(y_test).type(torch.FloatTensor).unsqueeze(0)
    y1_tensor_test_indices = torch.from_numpy(test_indices).type(torch.FloatTensor).unsqueeze(0)
    torch_dataset_test = Data.TensorDataset(x1_tensor_test, y1_tensor_test, y1_tensor_test_indices)

    train_iter = Data.DataLoader(
        dataset=torch_dataset_train,  # torch TensorDataset format
        batch_size=1,  # mini batch size
        shuffle=False,  # 要不要打乱数据 (打乱比较好)
        num_workers=1,  # 多线程来读数据
        pin_memory=True,
    )
    valiada_iter = Data.DataLoader(
        dataset=torch_dataset_valida,  # torch TensorDataset format
        batch_size=1,  # mini batch size
        shuffle=False,  # 要不要打乱数据 (打乱比较好)
        num_workers=1,  # 多线程来读数据
        pin_memory=True,
    )
    test_iter = Data.DataLoader(
        dataset=torch_dataset_test,  # torch TensorDataset format
        batch_size=1,  # mini batch size
        shuffle=False,  # 要不要打乱数据 (打乱比较好)
        num_workers=1,  # 多线程来读数据
        pin_memory=True,
    )
    return train_iter, valiada_iter, test_iter


def generate_png(net, gt, device, test_iter, total_indices, flag, map_all):
    for X, y, w in test_iter:
        X = X.to(device)
        net.eval()  # 评估模式, 这会关闭dropout
        y_pred, x_s = net(X)
        y_pred = y_pred.argmax(dim=1).cpu()

    x = np.ravel(y_pred)

    x = x + 1
    # 循环结束
    yy = x.reshape(gt.shape[0], gt.shape[1])

    mask = (gt == 0)
    yy[mask] = 0

    from PIL import Image
    yy = yy.astype(np.uint8)
    im = Image.fromarray(yy)

    max_label = int(gt.max())
    if max_label == 16:
        # y_gt = list_to_colormap1(gt)
        y_list = list_to_colormap1(x)
    elif max_label == 8:
        # y_gt = list_to_colormap3(gt)
        y_list = list_to_colormap3(x)
    elif max_label == 10:
        # y_gt = list_to_colormap4(gt)
        y_list = list_to_colormap4(x)
    elif max_label == 6:
        # y_gt = list_to_colormap5(gt)
        y_list = list_to_colormap5(x)
    elif max_label == 18:
        # y_gt = list_to_colormap6(gt)
        y_list = list_to_colormap6(x)
    else:
        # y_gt = list_to_colormap2(gt)
        y_list = list_to_colormap2(x)
    # y_list = list_to_colormap(x)
    y_re = np.reshape(y_list, (gt.shape[0], gt.shape[1], 3))

    import datetime
    day = datetime.datetime.now()
    day_str = day.strftime('%m_%d_%H_%M_%S_')

    # 定义保存目录
    save_dir = "./classification_maps"
    os.makedirs(save_dir, exist_ok=True)  # 创建目录，exist_ok=True表示若存在则不报错

    # 保存tif格式
    tif_path = os.path.join(save_dir, day_str + '_' + flag + '.tif')
    im.save(tif_path)

    # 保存png格式
    png_path = os.path.join(save_dir, day_str + '_' + flag + '.png')
    classification_map(y_re, gt, 300, png_path)




def list_to_colormap1(x_list):
        y = np.zeros((x_list.shape[0], 3))
        for index, item in enumerate(x_list):
            if item == 0:
                y[index] = np.array([0, 0, 0]) / 255.  # 背景色
            if item == 1:
                y[index] = np.array([176, 48, 96]) / 255.  # 红色
            if item == 2:
                y[index] = np.array([0, 255, 255]) / 255.  # 橙色
            if item == 3:
                y[index] = np.array([255, 0, 254]) / 255.  # 黄色
            if item == 4:
                y[index] = np.array([160, 32, 239]) / 255.  # 黄绿色
            if item == 5:
                y[index] = np.array([126, 255, 212]) / 255.  # 绿色
            if item == 6:
                y[index] = np.array([128, 255, 0]) / 255.  # 青绿色
            if item == 7:
                y[index] = np.array([0, 205, 0]) / 255.  # 青色
            if item == 8:
                y[index] = np.array([0, 255, 1]) / 255.  # 蓝色
            if item == 9:
                y[index] = np.array([1, 139, 0]) / 255.  # 深蓝色
            if item == 10:
                y[index] = np.array([254, 0, 0]) / 255.  # 紫罗兰色
            if item == 11:
                y[index] = np.array([215, 191, 215]) / 255.  # 紫色
            if item == 12:
                y[index] = np.array([255, 127, 80]) / 255.  # 粉红色
            if item == 13:
                y[index] = np.array([160, 82, 44]) / 255.  # 浅红色
            if item == 14:
                y[index] = np.array([255, 255, 255]) / 255.  # 深橙色
            if item == 15:
                y[index] = np.array([218, 112, 213]) / 255.  # 桃红色
            if item == 16:
                y[index] = np.array([0, 0, 254]) / 255.  # 淡紫色
            if item == -1:
                y[index] = np.array([0, 0, 0]) / 255.  # 处理无效标签
        return y

def list_to_colormap2(x_list):
        y = np.zeros((x_list.shape[0], 3))
        for index, item in enumerate(x_list):
            if item == 0:
                y[index] = np.array([0, 0, 0]) / 255.  # 背景色
            if item == 1:
                y[index] = np.array([254, 0, 0]) / 255.  # 红色
            if item == 2:
                y[index] = np.array([255, 255, 255]) / 255.  # 橙色
            if item == 3:
                y[index] = np.array([176, 48, 96]) / 255.  # 黄色
            if item == 4:
                y[index] = np.array([255, 255, 0]) / 255.  # 黄绿色
            if item == 5:
                y[index] = np.array([255, 127, 80]) / 255.  # 绿色
            if item == 6:
                y[index] = np.array([0, 255, 1]) / 255.  # 青绿色
            if item == 7:
                y[index] = np.array([0, 205, 0]) / 255.  # 青色
            if item == 8:
                y[index] = np.array([2, 127, 1]) / 255.  # 蓝色
            if item == 9:
                y[index] = np.array([126, 255, 212]) / 255.  # 深蓝色
            if item == 10:
                y[index] = np.array([160, 32, 239]) / 255.  # 紫罗兰色
            if item == 11:
                y[index] = np.array([215, 191, 215]) / 255.  # 紫色
            if item == 12:
                y[index] = np.array([0, 0, 254]) / 255.  # 粉红色
            if item == 13:
                y[index] = np.array([1, 0, 138]) / 255.  # 浅红色
            if item == 14:
                y[index] = np.array([218, 112, 213]) / 255.  # 深橙色
            if item == 15:
                y[index] = np.array([160, 82, 44]) / 255.  # 桃红色
            if item == 16:
                y[index] = np.array([0, 255, 255]) / 255.  # 淡紫色
            if item == 17:
                y[index] = np.array([254, 165, 0]) / 255.  # 黄色
            if item == 18:
                y[index] = np.array([128, 255, 0]) / 255.  # 深紫色
            if item == 19:
                y[index] = np.array([138, 139, 1]) / 255.  # 深蓝色
            if item == 20:
                y[index] = np.array([0, 138, 138]) / 255.  # 深紫罗兰色
            if item == 21:
                y[index] = np.array([205, 181, 205]) / 255.  # 棕色
            if item == 22:
                y[index] = np.array([239, 154, 1]) / 255.  # 靛蓝色
            if item == -1:
                y[index] = np.array([0, 0, 0]) / 255.  # 处理无效标签
        return y

def list_to_colormap3(x_list):
        y = np.zeros((x_list.shape[0], 3))
        for index, item in enumerate(x_list):
            if item == 0:
                y[index] = np.array([0, 0, 0]) / 255.  # 背景色
            if item == 1:
                y[index] = np.array([252, 1, 1]) / 255.  # 红色
            if item == 2:
                y[index] = np.array([0, 0, 254]) / 255.  # 橙色
            if item == 3:
                y[index] = np.array([1, 255, 0]) / 255.  # 黄色
            if item == 4:
                y[index] = np.array([255, 0, 254]) / 255.  # 黄绿色
            if item == 5:
                y[index] = np.array([255, 255, 255]) / 255.  # 绿色
            if item == 6:
                y[index] = np.array([255, 254, 1]) / 255.  # 青绿色
            if item == 7:
                y[index] = np.array([2, 254, 255]) / 255.  # 青色
            if item == 8:
                y[index] = np.array([47, 138, 86]) / 255.  # 蓝色
            if item == -1:
                y[index] = np.array([0, 0, 0]) / 255.  # 处理无效标签
        return y

def list_to_colormap4(x_list):
        y = np.zeros((x_list.shape[0], 3))
        for index, item in enumerate(x_list):
            if item == 0:
                y[index] = np.array([0, 0, 0]) / 255.  # 背景色
            if item == 1:
                y[index] = np.array([139, 67, 45]) / 255.  # 红色
            if item == 2:
                y[index] = np.array([0, 0, 255]) / 255.  # 橙色
            if item == 3:
                y[index] = np.array([0, 199, 0]) / 255.  # 黄色
            if item == 4:
                y[index] = np.array([100, 173, 255]) / 255.  # 黄绿色
            if item == 5:
                y[index] = np.array([2163, 74, 155]) / 255.  # 绿色
            if item == 6:
                y[index] = np.array([192, 80, 70]) / 255.  # 青绿色
            if item == 7:
                y[index] = np.array([59, 91, 111]) / 255.  # 青色
            if item == 8:
                y[index] = np.array([255, 255, 0]) / 255.  # 蓝色
            if item == 9:
                y[index] = np.array([255, 99, 0]) / 255.  # 青色
            if item == 10:
                y[index] = np.array([118, 253, 172]) / 255.  # 蓝色
            if item == -1:
                y[index] = np.array([0, 0, 0]) / 255.  # 处理无效标签
        return y

def list_to_colormap5(x_list):
        y = np.zeros((x_list.shape[0], 3))
        for index, item in enumerate(x_list):
            if item == 0:
                y[index] = np.array([0, 0, 0]) / 255.  # 背景色
            if item == 1:
                y[index] = np.array([10, 255, 0]) / 255.  # 红色
            if item == 2:
                y[index] = np.array([153, 153, 153]) / 255.  # 橙色
            if item == 3:
                y[index] = np.array([255, 99, 0]) / 255.  # 黄色
            if item == 4:
                y[index] = np.array([163, 74, 155]) / 255.  # 黄绿色
            if item == 5:
                y[index] = np.array([100, 173, 255]) / 255.  # 绿色
            if item == 6:
                y[index] = np.array([139, 67, 45]) / 255.  # 青绿色
            if item == -1:
                y[index] = np.array([0, 0, 0]) / 255.  # 处理无效标签
        return y

def list_to_colormap6(x_list):
        y = np.zeros((x_list.shape[0], 3))
        for index, item in enumerate(x_list):
            if item == 0:
                y[index] = np.array([0, 0, 0]) / 255.  # 背景色
            if item == 1:
                y[index] = np.array([139, 67, 45]) / 255.  # 红色
            if item == 2:
                y[index] = np.array([153, 153, 153]) / 255.  # 橙色
            if item == 3:
                y[index] = np.array([255, 99, 0]) / 255.  # 黄色
            if item == 4:
                y[index] = np.array([0, 255, 122]) / 255.  # 黄绿色
            if item == 5:
                y[index] = np.array([163, 74, 155]) / 255.  # 绿色
            if item == 6:
                y[index] = np.array([100, 173, 255]) / 255.  # 青绿色
            if item == 7:
                y[index] = np.array([118, 253, 172]) / 255.  # 青色
            if item == 8:
                y[index] = np.array([59, 91, 111]) / 255.  # 蓝色
            if item == 9:
                y[index] = np.array([255, 255, 0]) / 255.  # 深蓝色
            if item == 10:
                y[index] = np.array([255, 255, 124]) / 255.  # 紫罗兰色
            if item == 11:
                y[index] = np.array([255, 0, 255]) / 255.  # 紫色
            if item == 12:
                y[index] = np.array([99, 0, 255]) / 255.  # 粉红色
            if item == 13:
                y[index] = np.array([0, 172, 253]) / 255.  # 浅红色
            if item == 14:
                y[index] = np.array([0, 255, 0]) / 255.  # 深橙色
            if item == 15:
                y[index] = np.array([171, 174, 80]) / 255.  # 桃红色
            if item == 16:
                y[index] = np.array([100, 193, 59]) / 255.  # 淡紫色
            if item == 17:
                y[index] = np.array([138, 0, 0]) / 255.  # 黄色
            if item == 18:
                y[index] = np.array([0, 0, 255]) / 255.  # 深紫色
            if item == -1:
                y[index] = np.array([0, 0, 0]) / 255.  # 处理无效标签
        return y

