# Title: MHS-Mamba: A Multi-Hierarchical Semantic Model for UAV Hyperspectral Image Classification
# Author: Fengnian Zhao
# Completion Date: 2025.5
# Article Link: https://ieeexplore.ieee.org/document/11152542
# Code Link: https://github.com/KustAIRS/JSTARS-MHS-Mamba
# Please refer to the README.txt file for the detailed usage.
# Note: This code is for research purpose only. The code is not for commercial use.

import torch
from torch import nn
import math
from einops import rearrange
import torch.nn.functional as F
from mamba_simple import Mamba


# 对x进行切片
def split_band(x, move_num, spec_num):
    """
    输入: x (Tensor) - 形状为 [b, c, h, w] 的张量
    move_num: 每次移动的步长
    spec_num: 每次切片的大小
    返回: 形状为 [b, n, c, h, w] 的张量，其中 n 是根据 move_num 和 spec_num 计算得到的切片数量
    """
    b, c, h, w = x.shape
    slices = []
    for i in range(0, c, move_num):
        if i + spec_num > c:
            slice = x[:, c - spec_num:c, :, :]  # 取最后 spec_num 列
        else:
            slice = x[:, i:i + spec_num, :, :]
        slices.append(slice)
    slices = torch.stack(slices, dim=1)  # 将切片堆叠成新的维度
    return slices


# 等于 PreNorm，实现了层归一化
class LayerNormalize_SSMN(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)


# residual函数用于残差连接
class Residual_SSMN(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(x, **kwargs) + x


class LSmamba(nn.Module):
    def __init__(self, dim, depth):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(
                Residual_SSMN(LayerNormalize_SSMN(dim, Mamba(
                    d_model=dim,
                    d_state=64,
                    d_conv=4,
                    expand=2,
                    use_fast_path=False,
                )))
            )

    def forward(self, x):
        for attention in self.layers:
            x = attention(x)
        return x


class SpeMamba(nn.Module):
    def __init__(self, channels, token_num=8, group_num=4):
        super(SpeMamba, self).__init__()
        self.token_num = token_num
        self.group_channel_num = math.ceil(channels / token_num)
        self.channel_num = self.token_num * self.group_channel_num
        self.mamba = Mamba(
            d_model=self.group_channel_num,
            d_state=64,
            d_conv=4,
            expand=2,
        )
        self.proj = nn.Sequential(
            nn.GroupNorm(group_num, self.channel_num),
            nn.SiLU()
        )

    def padding_feature(self, x):
        B, C, H, W = x.shape
        if C < self.channel_num:
            pad_c = self.channel_num - C
            pad_features = torch.zeros((B, pad_c, H, W)).to(x.device)
            cat_features = torch.cat([x, pad_features], dim=1)
            return cat_features
        else:
            return x

    def forward(self, x):
        x_pad = self.padding_feature(x)
        x_pad = x_pad.permute(0, 2, 3, 1).contiguous()
        B, H, W, C_pad = x_pad.shape
        x_flat = x_pad.view(B * H * W, self.token_num, self.group_channel_num)
        x_flat = self.mamba(x_flat)
        x_recon = x_flat.view(B, H, W, C_pad)
        x_recon = x_recon.permute(0, 3, 1, 2).contiguous()
        x_proj = self.proj(x_recon)
        _, C, _, _ = x.shape
        if C_pad > C:
            x_proj = x_proj[:, :C, :, :]
        return x + x_proj


class SpaMamba(nn.Module):
    def __init__(self, channels, group_num=4, use_proj=True):
        super(SpaMamba, self).__init__()
        self.use_proj = use_proj
        self.mamba = Mamba(
            d_model=channels,
            d_state=64,
            d_conv=4,
            expand=2,
        )
        if self.use_proj:
            self.proj = nn.Sequential(
                nn.GroupNorm(group_num, channels),
                nn.SiLU()
            )

    def forward(self, x):
        x_re = x.permute(0, 2, 3, 1).contiguous()
        B, H, W, C = x_re.shape
        x_flat = x_re.view(1, -1, C)
        x_flat = self.mamba(x_flat)
        x_recon = x_flat.view(B, H, W, C)
        x_recon = x_recon.permute(0, 3, 1, 2).contiguous()
        if self.use_proj:
            x_recon = self.proj(x_recon)
        return x_recon + x


class SSIF_Mamba(nn.Module):
    def __init__(self, channels, token_num, group_num=4, use_att=True):
        super(SSIF_Mamba, self).__init__()
        self.use_att = use_att
        if self.use_att:
            self.weights = nn.Parameter(torch.ones(2) / 2)
            self.softmax = nn.Softmax(dim=0)
        self.spa_mamba = SpaMamba(channels, group_num=group_num)
        self.spe_mamba = SpeMamba(channels, token_num=token_num, group_num=group_num)

    def forward(self, x):
        spa_x = self.spa_mamba(x)
        spe_x = self.spe_mamba(x)
        if self.use_att:
            weights = self.softmax(self.weights)
            fusion_x = spa_x * weights[0] + spe_x * weights[1]
        else:
            fusion_x = spa_x + spe_x
        return fusion_x + x

class MHS_mamba(nn.Module):
    def __init__(self, num_classes=16, dim=64, depth=1, dropout=0.1, band=30, spec_num=12, spec_rate=0.5, device='0',
                 spa_token=16, token_num=8, group_num=4):
        super(MHS_mamba, self).__init__()
        self.name = 'MHS_mamba'
        self.spec_num = spec_num
        self.spec_rate = spec_rate
        self.move_num = int(math.ceil(self.spec_num * self.spec_rate))
        self.device = device

        self.preprocess = nn.Sequential(
            nn.Conv2d(in_channels=band, out_channels=dim, kernel_size=(1, 1)),
            nn.BatchNorm2d(dim),
            nn.GELU(),
        )

        # 空间分支
        self.conv2d_features1 = nn.Sequential(
            nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=(3, 3), padding=(1, 1)),
            nn.BatchNorm2d(dim),
            nn.GELU(),
        )
        self.conv2d_features2 = nn.Sequential(
            nn.AvgPool2d(kernel_size=5, stride=1, padding=2),
            nn.BatchNorm2d(dim),
            nn.GELU(),
        )
        self.conv2d_channel = nn.Sequential(
            nn.Conv2d(dim, out_channels=dim, kernel_size=(1, 1)),
            nn.BatchNorm2d(dim),
            nn.GELU(),
        )
        self.conv2d_fusion = nn.Sequential(
            nn.Conv2d(4 * dim, out_channels=dim, kernel_size=(1, 1)),
            nn.GELU(),
        )
        self.dropout = nn.Dropout(dropout)

        hidden_dim = dim
        self.SSmamba_block = nn.Sequential(
            SSIF_Mamba(channels=dim, token_num=8, group_num=4),
            # SSIF_Mamba(channels=hidden_dim, token_num=token_num, group_num=group_num),
            # SSIF_Mamba(channels=hidden_dim, token_num=token_num, group_num=group_num),
        )

        self.spa_token = spa_token
        self.nn1 = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
        )

        # 光谱分支
        num_patch = math.floor((dim - (self.spec_num - self.move_num)) / self.move_num) + \
                    math.ceil(
                        (((dim - (self.spec_num - self.move_num)) % self.move_num) + (self.spec_num - self.move_num)) /
                        self.move_num)
        self.spe_token1 = nn.Sequential(
            nn.Conv3d(1, 1, (1, 1, 7), stride=(1, 1, 1), padding=(0, 0, 3)),
            nn.LayerNorm(dim),
            nn.GELU(),
        )
        self.spe_token2 = nn.Sequential(
            nn.Conv3d(1, 1, (1, 1, 3), stride=(1, 1, 1), padding=(0, 0, 1)),
            nn.LayerNorm(dim),
            nn.GELU(),
        )

        self.SpecM = LSmamba(self.spec_num, depth)
        self.nn2 = nn.Sequential(
            nn.Linear(self.spec_num * num_patch, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
        )
        self.outhead = nn.Sequential(
            nn.AvgPool2d(kernel_size=3, stride=1, padding=1),
            nn.Conv2d(dim, num_classes, 1, 1, 0),
        )

    def forward(self, x, test=False):
        B, H, W, C = x.shape
        x = self.preprocess(x.permute(0, 3, 1, 2)).permute(0, 2, 3, 1)
        x_spe = x

        # 先空间后光谱
        x = x.permute(0, 3, 1, 2)
        #MLFE
        x1 = self.conv2d_channel(x)
        x2 = self.conv2d_features1(x)
        x3 = self.conv2d_features2(x)
        x = torch.cat([x, x1, x2, x3], dim=1)
        x = self.conv2d_fusion(x)
        x = self.dropout(x)
        x_s1 = x

        # expand H and W
        eH = self.spa_token - H % self.spa_token
        eW = self.spa_token - W % self.spa_token
        pad = torch.nn.ReflectionPad2d((0, eW, 0, eH)).to(self.device)
        x = pad(x)

        # 分块处理
        block_size = 16  # 可以根据实际情况调整分块大小
        num_blocks_h = (x.size(2) + block_size - 1) // block_size
        num_blocks_w = (x.size(3) + block_size - 1) // block_size
        output_blocks = []
        for i in range(num_blocks_h):
            start_h = i * block_size
            end_h = min(start_h + block_size, x.size(2))
            row_blocks = []
            for j in range(num_blocks_w):
                start_w = j * block_size
                end_w = min(start_w + block_size, x.size(3))
                block = x[:, :, start_h:end_h, start_w:end_w]
                block = self.SSmamba_block(block)
                row_blocks.append(block)
            output_blocks.append(torch.cat(row_blocks, dim=3))
        x = torch.cat(output_blocks, dim=2)

        x = x[:, :, :H, :W] + x_s1

        x = self.SSmamba_block(x)
        x = x.permute(0, 2, 3, 1)
        x_spa = self.nn1(x)

        # 光谱
        #LSFE
        x_s = x_spe.unsqueeze(1)
        x_s = self.spe_token1(x_s) + self.spe_token2(x_s) + x_s
        x_s = self.dropout(x_s).squeeze(1).permute(0, 3, 1, 2)
        Patch_pool = torch.nn.AvgPool2d((H, W)).to(self.device)
        x_s = Patch_pool(x_s)

        x_s = split_band(x_s, self.move_num, self.spec_num)
        bb, nn, cc, hh, ww = x_s.shape
        x_s = rearrange(x_s, 'b n c h w-> (b h w) n c')
        x_s = self.SpecM(x_s)
        x_s = rearrange(x_s, '(b h w) n c-> b (n c) (h w)', h=hh, w=ww).mean(-1)
        x_s = self.nn2(x_s).unsqueeze(1).unsqueeze(1)

        x = x_spa * x_s #change
        x = rearrange(x, 'b h w c-> b c h w')
        x = F.interpolate(x, size=(H, W), mode='bilinear', align_corners=False)
        x = self.outhead(x)

        if test is True:
            return x, x_spa, x_s
        else:
            return x, x_s
